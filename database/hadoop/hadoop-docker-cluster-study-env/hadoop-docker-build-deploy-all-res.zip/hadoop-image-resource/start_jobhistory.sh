#! /usr/bin/bash
cd /opt/hadoop-3.3.4/ 
bin/mapred --daemon start historyserver
while true;
do
    count=`ps aux | grep -v 'grep' | grep -c 'org.apache.hadoop.mapreduce'`
    if [ $count -eq 0 ]; then
            exit 1
    else
            now=`date +%F\ %T`
            echo "[$now] jobhistory service is online, everything seems to be OK..."
    fi
    sleep 10
done