#! /usr/bin/bash
cd /opt/hadoop-3.3.4/ 
# set -e
# bin/hdfs namenode -format
# set +e
service ssh start
bin/yarn --daemon start resourcemanager
while true;
do
    count=`ps aux | grep -v 'grep' | grep -c 'org.apache.hadoop.yarn.server'`
    if [ $count -eq 0 ]; then
            exit 1
    else
            now=`date +%F\ %T`
            echo "[$now] yara is online, everything seems to be OK..."
    fi
    sleep 10
done