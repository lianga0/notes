#! /usr/bin/bash
cd /opt/hadoop-3.3.4/ 
# set -e
# bin/hdfs namenode -format
# set +e
service ssh start
bin/hdfs --daemon start namenode
while true;
do
    count=`ps aux | grep -v 'grep' | grep -c 'apache.hadoop.hdfs.server'`
    if [ $count -eq 0 ]; then
            exit 1
    else
            now=`date +%F\ %T`
            echo "[$now] hadoop is online, everything seems to be OK..."
    fi
    sleep 10
done