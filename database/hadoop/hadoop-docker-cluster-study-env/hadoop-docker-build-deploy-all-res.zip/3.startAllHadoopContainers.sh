set +e

echo 1.启动namenode节点
docker container start namenode



echo 2.启动secondarynamenode节点
docker container start secondarynamenode



echo 3.启动三个datanode节点
docker container start datanode1
docker container start datanode2
docker container start datanode3



echo 4.启动resourcemanager节点
docker container start resourcemanager



echo 5.启动两个nodemanager节点
docker container start nodemanager1
docker container start nodemanager2



echo 6.启动jobhistory节点
docker container start jobhistory
