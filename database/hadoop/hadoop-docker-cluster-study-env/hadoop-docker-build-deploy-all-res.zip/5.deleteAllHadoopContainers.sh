set +e

echo 1.删除namenode节点
docker container rm -f namenode



echo 2.删除secondarynamenode节点
docker container rm -f secondarynamenode



echo 3.删除三个datanode节点
docker container rm -f datanode1
docker container rm -f datanode2
docker container rm -f datanode3



echo 4.删除resourcemanager节点
docker container rm -f resourcemanager



echo 5.删除两个nodemanager节点
docker container rm -f nodemanager1
docker container rm -f nodemanager2



echo 6.删除jobhistory节点
docker container rm -f jobhistory
