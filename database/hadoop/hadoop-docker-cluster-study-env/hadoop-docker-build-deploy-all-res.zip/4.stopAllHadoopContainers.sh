set +e

echo 1.停止三个datanode节点
docker container stop datanode1
docker container stop datanode2
docker container stop datanode3



echo 2.停止secondarynamenode节点
docker container stop secondarynamenode



echo 3.停止namenode节点
docker container stop namenode



echo 4.停止jobhistory节点
docker container stop jobhistory



echo 5.停止两个nodemanager节点
docker container stop nodemanager1
docker container stop nodemanager2



echo 6.停止resourcemanager节点
docker container stop resourcemanager
