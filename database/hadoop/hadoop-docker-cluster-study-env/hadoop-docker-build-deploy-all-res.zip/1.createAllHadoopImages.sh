set +e

cd hadoop-image-resource
echo 0.创建基础镜像hadoop-base
docker build -t hadoop-base -f Dockerfile.all.hadoop .


echo 1.创建namenode镜像
docker build -t namenode -f Dockerfile.all.namenode .



echo 2.创建secondarynamenode镜像
docker build -t secondarynamenode -f Dockerfile.all.secondarynamenode .



echo 3.创建datanode镜像
docker build -t datanode -f Dockerfile.all.datanode .



echo 4.创建resourcemanager镜像
docker build -t resourcemanager -f Dockerfile.all.resourcemanager .



echo 5.创建nodemanager镜像
docker build -t nodemanager -f Dockerfile.all.nodemanager .



echo 6.创建jobhistory镜像
docker build -t jobhistory -f Dockerfile.all.jobhistory .
