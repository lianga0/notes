set +e

echo 0.创建docker虚拟网络（hadoop）
docker network create --driver=bridge --subnet=172.32.3.0/16  --ip-range=172.32.3.0/24 --gateway=172.32.3.254 hadoop || docker network ls



echo 1.创建namenode节点
docker run -p 9870:9870 -p 22:22 --network hadoop --ip 172.32.3.10 --detach=true --name namenode --hostname namenode -it namenode



echo 2.创建secondarynamenode节点
docker run -P --network hadoop --ip 172.32.3.19 --detach=true --name secondarynamenode --hostname secondarynamenode secondarynamenode



echo 3.创建三个datanode节点
docker run -P --network hadoop --ip 172.32.3.11 --detach=true --name datanode1 --hostname datanode1 datanode
docker run -P --network hadoop --ip 172.32.3.12 --detach=true --name datanode2 --hostname datanode2 datanode
docker run -P --network hadoop --ip 172.32.3.13 --detach=true --name datanode3 --hostname datanode3 datanode



echo 4.创建resourcemanager节点
docker run -P --network hadoop --ip 172.32.3.20 --detach=true --name resourcemanager --hostname resourcemanager resourcemanager



echo 5.创建两个nodemanager节点
docker run -P --network hadoop --ip 172.32.3.21 --detach=true --name nodemanager1 --hostname nodemanager1 -it nodemanager
docker run -P --network hadoop --ip 172.32.3.22 --detach=true --name nodemanager2 --hostname nodemanager2 -it nodemanager



echo 6.创建jobhistory节点
docker run -P --network hadoop --ip 172.32.3.29 --detach=true --name jobhistory --hostname jobhistory jobhistory



echo 查看namenode节点状态网页：http://namenode:9870/dfshealth.html#tab-overview

echo 查看secondarynamenode节点状态网页：http://secondarynamenode:9868/status.html

echo 查看datanode节点状态网页：http://datanode1:9864/datanode.html

echo 查看resourcemanager节点状态网页：http://resourcemanager:8088/cluster

echo 查看nodemanager节点状态网页：http://nodemanager1:8042/node

echo 查看yarn jobhistory节点状态网页：http://jobhistory:19888/jobhistory



# Windows执行docker挂载卷
# docker run  -v /tmp:/host -it hadoop-base
