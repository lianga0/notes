#include <iostream>
#include "math_utils.h"

int main() {
    std::cout << "3 + 5 = " << add(3, 5) << std::endl;
    return 0;
}