#pragma once

extern void call_loadlibrary(char* dllPath);
extern void call_loadlibrary_end();
