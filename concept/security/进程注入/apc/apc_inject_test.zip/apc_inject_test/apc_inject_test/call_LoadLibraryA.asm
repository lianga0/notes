.CODE

call_loadlibrary PROC

	mov         qword ptr [rsp+18h],r8  
	mov         qword ptr [rsp+10h],rdx  
	mov         qword ptr [rsp+8],rcx  
	push        rsi  
	push        rdi  
	sub         rsp,178h  
	mov			rax, gs:[60h];_PEB
	mov			rax,  [rax+18h];_PEB_LDR_DATA
	mov			rax, [rax+10h];InLoadOrderModuleList
	mov			rax, [rax]
	mov			rax, [rax]
	mov			rax, [rax + 30h];kernel32 address
	cdqe  
	mov         qword ptr [rsp+28h],rax  
	mov         rax,qword ptr [rsp+28h]  
	mov         qword ptr [rsp+48h],rax  
	mov         rax,qword ptr [rsp+48h]  
	movsxd      rax,dword ptr [rax+3Ch]  
	mov         rcx,qword ptr [rsp+48h]  
	add         rcx,rax  
	mov         rax,rcx  
	mov         qword ptr [rsp+50h],rax  
	lea         rax,[rsp+00000080h]  
	mov         rcx,qword ptr [rsp+50h]  
	mov         rdi,rax  
	lea         rsi,[rcx+18h]  
	mov         ecx,0F0h  
	rep movs    byte ptr [rdi],byte ptr [rsi]  
	mov         eax,8  
	imul        rax,rax,0  
	mov         eax,dword ptr [rsp+rax+000000F0h]  
	mov         rcx,qword ptr [rsp+28h]  
	add         rcx,rax  
	mov         rax,rcx  
	mov         qword ptr [rsp+30h],rax  
	mov         rax,qword ptr [rsp+30h]  
	mov         eax,dword ptr [rax+20h]  
	mov         rcx,qword ptr [rsp+28h]  
	add         rcx,rax  
	mov         rax,rcx  
	mov         qword ptr [rsp+78h],rax  
	mov         rax,qword ptr [rsp+30h]  
	mov         eax,dword ptr [rax+24h]  
	mov         rcx,qword ptr [rsp+28h]  
	add         rcx,rax  
	mov         rax,rcx  
	mov         qword ptr [rsp+68h],rax  
	mov         rax,qword ptr [rsp+30h]  
	mov         eax,dword ptr [rax+1Ch]  
	mov         rcx,qword ptr [rsp+28h]  
	add         rcx,rax  
	mov         rax,rcx  
	mov         qword ptr [rsp+60h],rax  
	mov         rax,qword ptr [rsp+30h]  
	mov         eax,dword ptr [rax+10h]  
	mov         qword ptr [rsp+58h],rax  
	mov         qword ptr [rsp+38h],0  
	jmp         s1  
s5:
	mov         rax,qword ptr [rsp+38h]  
	inc         rax  
	mov         qword ptr [rsp+38h],rax  
s1:
	mov         rax,qword ptr [rsp+30h]  
	mov         eax,dword ptr [rax+14h]  
	cmp         qword ptr [rsp+38h],rax  
	jae         s2  
	mov         rax,qword ptr [rsp+78h]  
	mov         rcx,qword ptr [rsp+38h]  
	mov         eax,dword ptr [rax+rcx*4]  
	mov         rcx,qword ptr [rsp+28h]  
	add         rcx,rax  
	mov         rax,rcx  
	mov         qword ptr [rsp+20h],rax  
	mov         rax,qword ptr [rsp+20h]  
	movsx       eax,byte ptr [rax]  
	cmp         eax,4Ch  
	jne         s3  
	mov         rax,qword ptr [rsp+20h]  
	movsx       eax,byte ptr [rax+1]  
	cmp         eax,6Fh  
	jne         s3  
	mov         rax,qword ptr [rsp+20h]  
	movsx       eax,byte ptr [rax+2]  
	cmp         eax,61h  
	jne         s3  
	mov         rax,qword ptr [rsp+20h]  
	movsx       eax,byte ptr [rax+3]  
	cmp         eax,64h  
	jne         s3  
	mov         rax,qword ptr [rsp+20h]  
	movsx       eax,byte ptr [rax+4]  
	cmp         eax,4Ch  
	jne         s3  
	mov         rax,qword ptr [rsp+20h]  
	movsx       eax,byte ptr [rax+5]  
	cmp         eax,69h  
	jne         s3  
	mov         rax,qword ptr [rsp+20h]  
	movsx       eax,byte ptr [rax+6]  
	cmp         eax,62h  
	jne         s3  
	mov         rax,qword ptr [rsp+20h]  
	movsx       eax,byte ptr [rax+7]  
	cmp         eax,72h  
	jne         s3  
	mov         rax,qword ptr [rsp+20h]  
	movsx       eax,byte ptr [rax+8]  
	cmp         eax,61h  
	jne         s3  
	mov         rax,qword ptr [rsp+20h]  
	movsx       eax,byte ptr [rax+9]  
	cmp         eax,72h  
	jne         s3  
	mov         rax,qword ptr [rsp+20h]  
	movsx       eax,byte ptr [rax+0Ah]  
	cmp         eax,79h  
	jne         s3  
	mov         rax,qword ptr [rsp+20h]  
	movsx       eax,byte ptr [rax+0Bh]  
	cmp         eax,41h  
	jne         s3  
	mov         rax,qword ptr [rsp+68h]  
	mov         rcx,qword ptr [rsp+38h]  
	movzx       eax,word ptr [rax+rcx*2]  
	mov         rcx,qword ptr [rsp+58h]  
	lea         rax,[rax+rcx-1]  
	mov         dword ptr [rsp+40h],eax  
	mov         eax,dword ptr [rsp+40h]  
	mov         rcx,qword ptr [rsp+60h]  
	mov         eax,dword ptr [rcx+rax*4]  
	mov         rcx,qword ptr [rsp+28h]  
	add         rcx,rax  
	mov         rax,rcx  
	mov         qword ptr [rsp+70h],rax  
	mov         rcx,qword ptr [rsp+00000190h]  
	call        qword ptr [rsp+70h]  
	mov         al,1  
	jmp         s4  
s3:
	jmp         s5  
s2:
	xor         al,al  
s4:
	add         rsp,178h  
	pop         rdi  
	pop         rsi  
	ret  
		
call_loadlibrary ENDP

call_loadlibrary_end PROC

call_loadlibrary_end ENDP

END
