// demo.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <Windows.h>
#include<stdlib.h>

int main()
{
	system("pause");
	MessageBoxA(NULL, "Test", "FristBox", MB_OK);
	system("pause");

	/*
	HMODULE hDll = LoadLibraryA("IAT_HOOK.dll");
	if (hDll == NULL) {
		MessageBoxA(NULL, "Failed to load DLL!", "FristBox", MB_OK);
		return 1;
	}
	*/

	MessageBoxA(NULL, "Test", "SecondBox", MB_OK);
	system("pause");
    return 0;
}
